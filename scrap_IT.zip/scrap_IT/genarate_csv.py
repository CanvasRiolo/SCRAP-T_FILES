import os
import pandas as pd

def run(class_name):
    # Function to find CSV files in a folder
    def find_csv_files(folder_path):
        csv_files = []
        for file in os.listdir(folder_path):
            if file.endswith('.csv'):
                csv_files.append(os.path.join(folder_path, file))
        return csv_files

    # Set the default folder path
    folder_path = r'C:\Users\OVI DUTTA\PycharmProjects\scrap_IT\outputs\raw_data'

    # Find CSV files in the folder
    csv_files = find_csv_files(folder_path)

    # Check if any CSV files are found
    if len(csv_files) == 0:
        print("No CSV files found in the specified folder.")
        exit()
    elif len(csv_files) == 1:
        selected_file = csv_files[0]  # Automatically select the only CSV file found
    else:
        # Prompt user to select a CSV file
        print("Found the following CSV files:")
        for idx, file in enumerate(csv_files):
            print(f"{idx + 1}. {file}")

        selected_file_idx = int(input("Enter the number corresponding to the CSV file you want to use: ")) - 1
        selected_file = csv_files[selected_file_idx]

    # Read the selected CSV file into a DataFrame
    df = pd.read_csv(selected_file)

    print(df)

    # Prompt user to input the search string

    # Prompt user to input the class name for further filtering
    selected_class = class_name

    # Check if class name is provided
    if selected_class:
        # Filter the DataFrame based on the class name
        results = df[df['Class'] == selected_class]

        # Print the filtered DataFrame based on the selected class
        results.to_csv("final_output.csv")
    else:
        print("No class name provided. Skipping class-based filtering.")
