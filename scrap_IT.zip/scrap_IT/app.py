import csv
from flask import Flask, redirect, render_template, request, session, url_for
import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
import uuid
import get_class as gs
import genarate_csv as gcsv

app = Flask(__name__)

client = MongoClient('mongodb://localhost:27017/')
db = client['url_database']
collection = db['urls']

# Secret key for session management
app.secret_key = 'your_secret_key'


# Function to scrape a web page
def scrape_page(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    print("URL: " + url)
    r = requests.get(url, headers=headers)
    r.raise_for_status()  # Raise an exception for 4xx or 5xx HTTP status codes
    soup = BeautifulSoup(r.content, "html.parser")
    return soup


# Function to extract data from HTML content
def get_data(content):
    class_contents = {}
    elements_with_class = content.find_all(class_=True)
    # Extract classes and subclasses
    for i in elements_with_class:
        class_name = ' '.join(i['class'])
        tagname = i.name
        if class_name not in class_contents:
            class_contents[class_name] = {'subclasses': {}}
        if tagname not in class_contents[class_name]['subclasses']:
            class_contents[class_name]['subclasses'][tagname] = []
        class_contents[class_name]['subclasses'][tagname].append(i.text.strip())
    return class_contents


# Function to save data to CSV file with unique name
def save_to_csv(data):
    filename = f'outputs/raw_data/output_{uuid.uuid4()}.csv'
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Class', 'Tag', 'Content'])
        for class_name, class_data in data.items():
            for tag_name, contents in class_data['subclasses'].items():
                for content in contents:
                    writer.writerow([class_name, tag_name, content])
    return filename


# Route for the homepage
@app.route('/')
def welcome():
    return render_template('login.html')


# Route for processing login
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        # Perform login validation here if needed
        # For simplicity, just redirect to the hello page
        return redirect(url_for('hello'))


@app.route("/search", methods=['GET', 'POST'])
def search():
    return render_template("search.html")


# Route for the hello page
@app.route('/hello')
def hello():
    return render_template('index.html')


# Route for scraping a URL and saving data
@app.route('/register', methods=['POST'])
def scrape():
    if request.method == 'POST':
        url = request.form['url-check']
        try:
            soup = scrape_page(url)
            collection.insert_one({'url': url})
            # Now call get_data to process the content
            data = get_data(soup)
            filename = save_to_csv(data)
            return render_template('search_string.html', url=url, class_contents=data, filename=filename)
        except requests.exceptions.RequestException as e:
            return f'Error occurred during request: {str(e)}'
        except Exception as e:
            return f'Error occurred: {str(e)}'
    return 'Method Not Allowed', 405


@app.route('/search_class', methods=['POST', 'GET'])
def search_class():
    search_string = request.form['search_string']
    data = gs.run(search_string)
    print(data)
    data_class = data['Class'].values
    data_tag = data['Tag'].values
    data_content = data['Content'].values
    data = {
        "Class":list(data_class),
        "Tag":list(data_tag),
        "Content":list(data_content)
    }
    data["length"]=len(data["Class"])
    return render_template("search_class.html", data=data)

@app.route('/generate_csv', methods=['POST', 'GET'])
def generate_csv():
    class_name=request.form['class_name']
    print(class_name)
    gcsv.run(class_name)
    return "CSV generated in backend !"



if __name__ == '__main__':
    app.run()
